<?php
function get_categories() {
    global $db;
    $query = 'SELECT * FROM categories
              ORDER BY categoryID';
    $statement = $db->prepare($query);
    $statement->execute();
    return $statement;    
}

function get_category_name($category_id) {
    global $db;
    $query = 'SELECT * FROM categories
              WHERE categoryID = :category_id';    
    $statement = $db->prepare($query);
    $statement->bindValue(':category_id', $category_id);
    $statement->execute();    
    $category = $statement->fetch();
    $statement->closeCursor();    
    $category_name = $category['categoryName'];
    return $category_name;
}

function add_category($category) {
    global $db;
    
    //enter the new category name into the database
    $query = 'INSERT INTO categories (categoryName)
              VALUES (:category)';
    
    //prepare the query statement for entering into database
    $statement = $db-> prepare($query);
    $statement -> bindValue(':category', $category);
    $statement -> execute();
    $statement -> closeCursor();
 
}

function delete_category($categoryID)
{
    global $db;
    
    //create & prepare query statement for deletion from database
    $query = 'DELETE FROM categories WHERE categoryID = :categoryID ';

    $statement = $db -> prepare($query);
    $statement -> bindValue(':categoryID', $categoryID);
    $statement -> execute();
    $statement -> closeCursor();
    
}



?>